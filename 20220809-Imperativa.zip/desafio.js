//DESAFFFFFFFIO

//remeras en el jonca de los pantalones, como los invierto??

let pantalones = "pantalon"
let remeras = "remera"
let cajonPantalones = remeras
console.log(cajonPantalones)
// let cajonRemeras = "pantalon"

cajonPantalones = pantalones
console.log(cajonPantalones)
