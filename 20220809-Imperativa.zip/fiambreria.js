const prompt = require("prompt-sync")({ sigint: true })

// //FIAMBRERIA

let temperatura = null
let estaLloviendo = false
let pisoAscensor = null
let horaActual = null
const horaApertura = 0800 //pending: type date
const horaCierre = 2030
let cantidadQueso = 100
let deudaConLaMoni = 0
